import pygame

class UI:
    def __init__(self, surface):

        # setup
        self.display_surface = surface
        
        # health
        self.health_bar = pygame.image.load('graphics/ui/health_bar.png').convert_alpha()
        self.health_bar_topleft = (39, 24)
        self.bar_max_width = 152 # length of the red bar in the png
        self.bar_height = 4


        # coins
        self.coin = pygame.image.load('graphics/ui/coin.png').convert_alpha()
        self.coin_rect = self.coin.get_rect(topleft = (5, 50))
        self.font = pygame.font.Font('graphics/ui/ARCADEPI.TTF', 30)

    # connects to the main.py health so changing it there changes these values
    def show_health(self, current_health, full_health):
        self.display_surface.blit(self.health_bar,(5, -5))
        current_health_ratio = current_health / full_health # gives percentage on what our health will be
        # if current_health is 50% of maximum we just want 50% of that
        current_bar_width = self.bar_max_width * current_health_ratio
        # two tuppels needed. position and size
        health_bar_rect = pygame.Rect(self.health_bar_topleft, (current_bar_width, self.bar_height))
        # pygae.draw.rect(surface, color, rect)
        pygame.draw.rect(self.display_surface, 'red', health_bar_rect)
    
    def show_coins(self, amount):
        self.display_surface.blit(self.coin, self.coin_rect)
        #pygame forces whatever infront of render to be a string   text, antialias,color, background = NONE
        coin_amount_surface = self.font.render(str(amount), False, 'white')
        coin_amount_rectangle = coin_amount_surface.get_rect(midleft = (self.coin_rect.right + 10, self.coin_rect.centery))
        self.display_surface.blit(coin_amount_surface, coin_amount_rectangle)
    
    def show_score(self, amount):
        score_amount_surface = self.font.render(('SCORE: ') + str(amount), False, 'white')
        score_amount_rectangle = score_amount_surface.get_rect(midleft = (500, 30))
        self.display_surface.blit(score_amount_surface, score_amount_rectangle)
